
package arraylisttoarray;
import java.util.ArrayList;
import java.util.ListIterator;
public class ArraylistToArray {

    public static void main(String[] args) {
        String[] array=new String[4];
         int i=0;
        ArrayList<String> list=new ArrayList<>();
        list.add("Chennai");
        list.add("Banglore");
        list.add("Mumbai");
        list.add("Delhi");
        System.out.println("In Array list:\n"+list);
        ListIterator<String> listIterator=list.listIterator();
        while(listIterator.hasNext())
        {
        array[i]=listIterator.next();
        i++;
        }
        System.out.println("After copied to an array:");
        for(String s:array){
        System.out.println(s);
        }
    }
    
}
