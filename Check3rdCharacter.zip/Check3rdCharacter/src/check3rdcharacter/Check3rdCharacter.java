/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * 2.write a program to accept a string and check whether 3rd character of string is 'S' or not.

 */
package check3rdcharacter;
import java.util.*;
public class Check3rdCharacter {
    
    public static void main(String[] args) {
       Check3rdCharacter ob=new Check3rdCharacter();
       ob.fun1();
    }
    public void fun1()
    {
     Scanner sin=new Scanner(System.in);
        char[] str=new char[25];
        System.out.println("Enter a String:");
        str=sin.next().toCharArray();
        if(str[2]!='s')
        {
        System.out.println("The third character is not 's'");
        }
        else
        {
        System.out.println("The third character is s");
        }
    }
    
}
