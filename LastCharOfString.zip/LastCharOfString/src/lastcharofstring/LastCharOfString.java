/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lastcharofstring;
import java.util.*;
public class LastCharOfString{
    public static void main(String[] args) {
        LastCharOfString ob=new LastCharOfString();
        ob.fun1();
    }
    public void fun1()
    {
        int lastchar=0;
        Scanner sin=new Scanner(System.in);
        char[] str=new char[30];
    System.out.println("Enter a String:");
    str=sin.next().toCharArray();
    lastchar=str.length-1;
    System.out.println("the last character is:"+str[lastchar]);
    }
}
