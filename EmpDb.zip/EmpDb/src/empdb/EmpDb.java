/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empdb;
import java.util.*;
/**
 *
 * @author MRuser
 */
public class EmpDb {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String EmpId="null",EmpName="null",EmpDept="null",ElderName="null",MaxSalPerson="null";
        int EmpAge=0,EmpSal=0,MaxSalary=0,Elder=0;
        Scanner sin=new Scanner(System.in);
       for(int i=0;i<11;i++)
       {
       System.out.println("Enter Emp Id");
      EmpId=sin.next();
      System.out.println("Enter Emp Name");
      EmpName=sin.next();
      System.out.println("Enter Emp Dept");
      EmpDept=sin.next();
      System.out.println("Enter Emp Age");
      EmpAge=sin.nextInt();
      if(EmpAge>Elder)
      {
      Elder=EmpAge;
      ElderName=EmpName;
      }
      System.out.println("Enter Emp Salary");
      EmpSal=sin.nextInt();
      if(EmpSal>MaxSalary)
      {
      MaxSalary=EmpSal;
      MaxSalPerson=EmpName;
      }
       }
       System.out.println(MaxSalPerson+" is earning more than others!");
       System.out.println(ElderName+" is eldest of all!");
    }
    
}
