
package highestnumber;
import java.util.*;
public class HighestNumber {

   
    public static void main(String[] args) {
        int number=0,maxNumber=0;
        Scanner sin=new Scanner(System.in);
        for(int i=0;i<3;i++)
        {
        System.out.println("Enter a number:");
        number=sin.nextInt();
        if(number>maxNumber)
        {
        maxNumber=number;
        }
        }
        System.out.println("Highest of 3 numbers is:"+maxNumber);
    }
    
}
