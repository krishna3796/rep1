/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeedatamanipulation;
import java.util.*;
/**
 *
 * @author MRuser
 */
public class EmployeeDataManipulation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String EmpName="null";
        int EmpSal=0,EmpBonus=0;
        Scanner sin=new Scanner(System.in);
        for(int i=0;i<11;i++)
        {
        System.out.println("Enter Employee name:");
        EmpName=sin.next();
        System.out.println("Enter Employee Salary:");
        EmpSal=sin.nextInt();
        if(EmpSal>=1000 && EmpSal<5000)
        {
        EmpBonus+=(EmpSal/100)*30;
        }
        if(EmpSal>=5000 && EmpSal<10000)
        {
        EmpBonus+=(EmpSal/100)*20;
        }
        if(EmpSal>=10000)
        {
        EmpBonus+=(EmpSal/100)*10;
        }
        }
        System.out.println("Total Bonus given During Festival Season is:"+EmpBonus);
    }
    
}
