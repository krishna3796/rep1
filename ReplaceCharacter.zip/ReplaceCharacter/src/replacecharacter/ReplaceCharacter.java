package replacecharacter;

import java.util.Scanner;

public class ReplaceCharacter {

    public static void main(String[] args) {
        ReplaceCharacter ob=new ReplaceCharacter();
        ob.replace();
    }
    public void replace()
    {
    Scanner sin=new Scanner(System.in);
        char[] str=new char[30];
        int thirdchar=0;
    System.out.println("Enter a String:");
    str=sin.next().toCharArray();
    thirdchar=(str.length-str.length)+2;
    str[thirdchar]='T';
    System.out.println(str);
    }
}
