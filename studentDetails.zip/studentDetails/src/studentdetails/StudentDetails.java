/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentdetails;
import java.util.*;
/**
 *
 * @author Madhan_2
 */
public class StudentDetails {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sin=new Scanner(System.in);
        String studentName="null";
        String studentCity="NULL";
        int studentAge,ageCount=0,chennai=0,mumbai=0,delhi=0,kolkata=0;
        for(int i=0;i<4;i++)
        {System.out.println("Enter student name:");
        studentName=sin.next();
        
        
         System.out.println("Enter student Age:");
         studentAge=sin.nextInt();
         if(studentAge>21)
         {
             ageCount+=1;
         }
         
         System.out.println("Enter student city(chennai,mumbai,delhi,kolkata):");
         studentCity=sin.next();
         if(studentCity.equals("chennai"))
         {
         chennai+=1;
         }
         if(studentCity.equals("mumbai"))
         {
         mumbai+=1;
         }
         if(studentCity.equals("delhi"))
         {
         delhi+=1;
         }
         if(studentCity.equals("kolkata"))
         {
         kolkata+=1;
         }
        }
        
          System.out.println("Students in chennai: "+chennai);
          System.out.println("Students in mumbai: "+mumbai);
          System.out.println("Students in delhi: "+delhi);
          System.out.println("Students in kolkata: "+kolkata);
        System.out.println("Students whose age is greater than 21 is "+ageCount);
    }
}
