
package examples;
import java.util.*;
public class Examples 
{
    public static void main(String[] args) 
    {
       arraylistsample ob=new arraylistsample();
    }
    
}
class arraylistsample
{
    arraylistsample()
    {
ArrayList<String> name=new ArrayList<String>();
name.add("Krishna");
name.add("Sanjeev");
name.add("Kumar");
name.add("Bharath");

ArrayList<Integer> age=new ArrayList<Integer>();
age.add(24);
age.add(22);
age.add(43);
age.add(56);

ArrayList<String> city=new ArrayList<String>();
city.add("Chennai");
city.add("Mumbai");
city.add("Kolkata");
city.add("Banglore");

ArrayList<String> state=new ArrayList<String>();
state.add("Tamilnadu");
state.add("Kerala");
state.add("Jammu Kashmir");
state.add("Karnataka");
System.out.println("Names:");
for(String s:name)
{
System.out.println(s);
}
System.out.println("Age:");
for(int a:age)
{
System.out.println(a);
}
System.out.println("City:");
for(String s:city)
{
System.out.println(s);
}
System.out.println("State:");
for(String s:state)
{
System.out.println(s);
}
}
}