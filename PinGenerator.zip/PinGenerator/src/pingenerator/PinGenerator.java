
package pingenerator;
import java.util.*;
public class PinGenerator {
    public static void main(String[] args) {
     UserInput ob=new UserInput();
    }
    
}
class UserInput
{
    Scanner sin=new Scanner(System.in);
    int sum=1;
    String name=null,firstcharstring;
    Integer uniqueNumber=0,firstChar;
    char secondchar,thirdchar,fourthchar;
    UserInput()
    {
    System.out.println("Enter Name:");
    name=sin.next();
    int len=name.length();
    char[] namearray=new char[len];
    namearray=name.toCharArray();
    secondchar=namearray[0];
    thirdchar=namearray[len-1];
    
    System.out.println("Enter Unique Number(4 Digits):");
    uniqueNumber=sin.nextInt();
    List<Integer> list=new ArrayList<>();
    int i=0,sum=0;
    while(uniqueNumber!=0)
    {
    list.add(uniqueNumber%10);
    uniqueNumber=uniqueNumber/10;
    i++;
    }
    
    for(i=0;i<list.size();i++)
    {
    sum+=list.get(i);
    list.remove(i);
    list.add(i,0);
    }
    list.clear();
     if(sum>10)
     {
     while(sum!=0)
    {
    list.add(sum%10);
    sum=sum/10;
    i++;
    }
     for(i=0;i<list.size();i++)
    {
    sum+=list.get(i);
    list.remove(i);
    list.add(i,0);
    }
     }
   
firstChar=sum;

    switch(firstChar)
    {
        case 1: {
            fourthchar = '@';
        }
        break;
        case 2: {
            fourthchar = '.';
        }
        break;
        case 3: {
            fourthchar = ',';
        }
        break;
        case 4: {
            fourthchar = '!';
        }
        break;
        case 5: {
            fourthchar = '=';
        }
        break;
        case 6: {
            fourthchar = '<';
        }
        break;
        case 7: {
            fourthchar = '>';
        }
        break;
        case 8: {
            fourthchar = '#';
        }
        break;
            case 9: {
            fourthchar = '$';
        }
        break;
                   case 10: {
            fourthchar = '%';
        }
        break;
                   default:
                           {};
                                
    }
    System.out.println("Your Unique Key is:"+firstChar+""+secondchar+""+thirdchar+""+fourthchar);
    }
  
}
