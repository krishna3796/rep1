
package extractingduplicates;
public class ExtractingDuplicates {
    public static void main(String[] args) {
        int hasDuplicates=0;
       String[] ArraySet1 ={"one","ball","three"};
       String[] ArraySet2={"apple","ball","one"};
          /* ArraySet1[0]="one";
           ArraySet1[1]="ball";
           ArraySet1[2]="three";
           
           ArraySet2[0]="apple";
           ArraySet2[1]="ball";
           ArraySet2[2]="one";
*/

           
       for(int i=0;i<3;i++)
       {
           for(int j=0;j<3;j++)
           {
               if(ArraySet1[i].equals(ArraySet2[j]))
               {
               System.out.println(ArraySet1[i]+" has Duplicates");
               hasDuplicates+=1;
               }
           
           }
       }
      if(hasDuplicates==0)
      {
      System.out.println("no duplicates found");
      }
    }
    
}
