/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arithmeticoperations;
import java.util.*;
/**
 *
 * @author MRuser
 */
public class ArithmeticOperations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int UserInput=0;
        Scanner sin=new Scanner(System.in);
        ArithmeticOperations ob=new ArithmeticOperations();
        for(int i=0;i<100;i++)
        {
        System.out.println("1.addition\n" +
"2.subraction\n" +
"3.divisiom \n" +
"4.percentage\n" +
"5.multiplication\n" +
"6.exit");
        UserInput=sin.nextInt();
        if(UserInput==1)
        {
            System.out.println("Enter num1:");
            int num1=sin.nextInt();
            System.out.println("Enter num2:");
            int num2=sin.nextInt();
            int ans=ob.add(num1,num2);
        System.out.println("Answer is:"+ans);
        }
        if(UserInput==2)
        {
            System.out.println("Enter num1:");
            int num1=sin.nextInt();
            System.out.println("Enter num2:");
            int num2=sin.nextInt();
            int ans=ob.sub(num1,num2);
        System.out.println("Answer is:"+ans);
        }
        if(UserInput==3)
        {
            System.out.println("Enter num1:");
            int num1=sin.nextInt();
            System.out.println("Enter num2:");
            int num2=sin.nextInt();
            int ans=ob.mul(num1,num2);
        System.out.println("Answer is:"+ans);
        }
        if(UserInput==4)
        {
            System.out.println("Enter num1:");
            int num1=sin.nextInt();
            System.out.println("Enter num2:");
            int num2=sin.nextInt();
            int ans=ob.div(num1,num2);
            System.out.println("Answer is:"+ans);
        }
        if(UserInput==6)
        {
            break;
        }
        }
        
    }
    public int add(int a,int b)
    {
    int c;
    c=a+b;
    return c;
    }
     public int sub(int a,int b)
    {
    int c;
    c=a-b;
    return c;
    } 
     public int mul(int a,int b)
    {
    int c;
    c=a*b;
    return c;
    }
      public int div(int a,int b)
    {
    int c;
    c=a/b;
    return c;
    }
}
