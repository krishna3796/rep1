/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reversestring;
        import java.util.Scanner;

/**
 *
 * @author Madhan_2
 */
public class ReverseString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
char temp;
Scanner sin=new Scanner(System.in);
System.out.println("Enter a string:");
String str=sin.next();
//char[] arr=str.toCharArray();
//String str="Krishna"; 
char[] arr=str.toCharArray();
int count=arr.length-1;
for(int i=0;i<=arr.length-1;i++)
{
temp=arr[i];
for(int j=count;j>=i;j--)
{
arr[i]=arr[j];
arr[j]=temp;
//System.out.println(arr);
break;
}
count=count-1;
}
System.out.println(arr);
}
    
}
